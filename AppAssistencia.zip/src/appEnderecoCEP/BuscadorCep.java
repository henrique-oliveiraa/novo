//por algum motivo a biblioteca não tá funcionando e 
//eu não consigo entender o por que mas vou tentar fazer o que supostamente devia acontecer
package appEnderecoCEP;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
public class BuscadorCep {

    static String webService = "http://viacep.com.br/ws/";  //EndereÃ§o viacep
    static String webremnant = "/json";                     //tipo de retorno
    static int codigoSucesso = 200;                         //CÃ³digo Sucesso conexÃ£o

    public static String encontraCep(String cep) {

        //Montagem da URL de chamada
        String urlChamada = webService + cep + webremnant;
        String dados = "";
        String jsonEmString = "";

        try {

            //Objeto para instanciar uma URL
            URL url = new URL(urlChamada);

            //Realiza a conexÃ£o com o site
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();

            //Se a conexÃ£o for bem sucedida, segue o processamento normalmente.
            //Caso contrÃ¡rio, exibe a informaÃ§Ã£o do tipo de problema de conexÃ£o. 0
            if (conexao.getResponseCode() != codigoSucesso) {
                throw new RuntimeException("Erro conexão!" + conexao.getResponseMessage());
            }

            BufferedReader resposta = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
            //Streaming: tecnologia de transmissÃ£o de dados pela internet
            //BufferReader: classe que realiza a armazenagem destes dados, em um ponteiro para posterior operaÃ§Ã£o
            //InputStreamReader: classe para realizar a leitura destes valores vindos do servidor (json, video)
            //getInputStream: retorna as informaÃ§Ãµes enviadas pelo servidor

            //Transformar o arquivo json em um arquivo de dados String
            while ((dados = resposta.readLine()) != null) {
                jsonEmString += dados;
            }

            System.out.println("String Json: " + jsonEmString);
                      
            //Transformar um json
            JSONObject obj = new JSONObject(jsonEmString);
            System.out.println(obj);
            
            String estado = obj.getString("estado");
            System.out.println("Estado: "+ estado);
            
            String cidade = obj.getString("localidade"); 
            System.out.println("Cidade: " + cidade);
            
            String rua = obj.getString("logradouro"); 
            System.out.println("Rua: " + rua);
            
            String bairro = obj.getString("bairro");
            System.out.println("Bairro: " + bairro);
            
            
            return estado + "," + cidade + "," + bairro + "," + rua;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}