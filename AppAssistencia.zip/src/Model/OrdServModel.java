package Model;

import DAL.OperInsereRegistroBD;
import DAL.OperTesteOrdemServ;
import java.util.ArrayList;

public class OrdServModel {

    public String id; // ordem de serviço

    public String equip;
    public String descDefeito;
    public String servico;
    public String tecnico;
    public String valor; 
    public String idClient;
    public String endereco;
    public String status;

    //Construtor vazio
    public OrdServModel() {
    }

    public OrdServModel(String idClient, String equip, String descDefeito) {
        this.equip = equip;
        this.descDefeito = descDefeito;
        this.idClient = idClient;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEquip() {
        return equip;
    }

    public void setEquip(String equip) {
        this.equip = equip;
    }

    public String getDescDefeito() {
        return descDefeito;
    }

    public void setDescDefeito(String descDefeito) {
        this.descDefeito = descDefeito;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getTecnico() {
        return tecnico;
    }

    public void setTecnico(String tecnico) {
        this.tecnico = tecnico;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    

    public ArrayList<ClienteModel> pesquisarPorIDModel(String idClient) {
        OperTesteOrdemServ op = new OperTesteOrdemServ();
        return op.pesquisarPorID(idClient);

    }
    
    
    public ArrayList<OrdServModel> pesquisarPorIDOrdServ(String idOrdServ){
    
    OperTesteOrdemServ op = new OperTesteOrdemServ();
    return op.pesquisarOrdServPorID(idOrdServ);
    
    
    }

    public void inserirRegistrosModel(OrdServModel novaOrdServ) {
        OperInsereRegistroBD op = new OperInsereRegistroBD();
        op.inserirRegistroOrdServ(novaOrdServ);
    }

}
