package Model;

import DAL.OperAtualizaDadosBD;
import DAL.OperExcluiDadosBD;
import DAL.OperFiltroDadosBD;
import DAL.OperInsereRegistroBD;
import DAL.OperListaDadosBD;
import java.util.ArrayList;

public class ClienteModel {

    //Atributos que definem o cadastro de um usuário
    private String id;
    private String clientName;
    private String CEP;
    private String adress;
    private String phoneNumb;
    private String email;

    // Métodos Contrutores - vazio
    public ClienteModel() {
    }

    //Construtor utilizado para listagem de dados contidos no banco
    public ClienteModel(String id, String clientName, String CEP, String adress, String phoneNumb, String email) {
        this.id = id;
        this.clientName = clientName;
        this.CEP = CEP;
        this.adress = adress;
        this.phoneNumb = phoneNumb;
        this.email = email;

    }

    //Construtor utilizado para inserir novo registro no banco de dados
    public ClienteModel(String clientName, String CEP, String adress, String phoneNumb, String email) {
        this.id = id;
        this.clientName = clientName;
        this.CEP = CEP;
        this.adress = adress;
        this.phoneNumb = phoneNumb;
        this.email = email;

    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getPhoneNumb() {
        return phoneNumb;
    }

    public void setPhoneNumb(String phoneNumb) {
        this.phoneNumb = phoneNumb;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    //Listagem de todos os dados
    public ArrayList<ClienteModel> listarRegistrosModel() {
        OperListaDadosBD op = new OperListaDadosBD();
        return op.listarRegistrosClientBd();
    }

    //Filtragem de dados
    /*public ArrayList<ClienteModel> filtrarRegistrosModel(String nome) {
        OperFiltroDadosBD op = new OperFiltroDadosBD();
        return op.filtrarRegistrosBD(nome);
    }*/
    //Inserção de um novo registro no banco de dados // Model
    public void inserirRegistrosModel(ClienteModel novoCliente) {
        OperInsereRegistroBD op = new OperInsereRegistroBD();
        op.inserirRegistroCliente(novoCliente);
    }

    //Envio da informação para o DAL para exclusão de registro
    public void excluirRegistrosModel(String idUser) {
        OperExcluiDadosBD op = new OperExcluiDadosBD();
        op.excluirRegistroCliente(idUser);
    }

    //UPDATE - recebe o objeto com as informações atualizadas e envia para o banco dedados
    public void atualizarRegistrosModel(ClienteModel clienteAtualizado) {
        OperAtualizaDadosBD op = new OperAtualizaDadosBD();
        op.atualizarRegistroCliente(clienteAtualizado);

    }

}
